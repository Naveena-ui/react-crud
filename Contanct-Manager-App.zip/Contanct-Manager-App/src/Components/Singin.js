
import React from "react";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

let SignIn = () => {


  let [state, setState] = useState({
      loading : false,
      contact: {
         name:'',
          email: '',
          password: ''
      },
      errorMeassage: ''
  })

  

  let updateInput = (event) => {
      setState({
          ...state,
          contact:{
              ...state.contact,
              [event.target.name]: event.target.value
          }
      })
  }



  let {contact, groups} = state;

  return(
      <React.Fragment>
          <section className="add-contact">
              <div className="container mt-2">
                  <div className="row d-flex justify-content-center">
                      <div className="col-md-4">
                          <h1 className="fw-bold">SignIn</h1>
                          <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Modi quibusdam at libero vel veniam necessitatibus delectus. Expedita numquam minus ipsum. Neque at vel recusandae eius magnam expedita enim laborum necessitatibus.</p>
                      </div>
                  </div>
              </div>
          </section>

          <section className="new-contact">
              <div className="container mt-5 ">
                  <div className="row d-flex justify-content-center">
                      <div className="col-md-4">
                          <form action="">
                          <div className="mb-2">
                                    <input 
                                    required={true}
                                    name="name"
                                    value={contact.name}
                                    onChange={updateInput}
                                    type="text" className="form-control" placeholder="Name" />
                                </div>
                              <div className="mb-2">
                                  <input 
                                  required={true}
                                  name="email"
                                  value={contact.email}
                                  onChange={updateInput}
                                  type="email" className="form-control" placeholder="Email" />
                              </div>
                              <div className="mb-2">
                                  <input 
                                  required={true}
                                  name="password"
                                  value={contact.password}
                                  onChange={updateInput}
                                  type="password" className="form-control" placeholder="password" />
                              </div>
                              <div className="row mt-2">
                <div className="col-md-6 mb-2">
                <Link to={'/login'} className="btn btn-success">Update</Link>

                </div>
               </div>
                          </form>
                      </div>
                  </div>
              </div>
          </section>

         
      </React.Fragment>
  )
}

export default SignIn;
