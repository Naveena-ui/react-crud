import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import ContactService from "../../Services/ContactService";
import Spinner from "../../Spinner/Spinner";

let ContactList = () => {

    let {contactId} = useParams()

    let [state, setState] = useState({
        loading : false,
        contacts : [],
        filteredContacts: [],
        errorMessage : '',
    })

    useEffect(()=>{
        let fetchData = async () => {
            try{
                setState({...state, loading : true})
                let response = await ContactService.getAllContacts();
                console.log(response.data);
                setState({
                    ...state,
                    loading : false,
                    contacts : response.data,
                    filteredContacts : response.data
                })
            }
            catch(error){
                setState({
                    ...state,
                    loading : false,
                    errorMessage : error.message
                })
            }
        }
        fetchData()
    },[])

    let deleteContact = (contactId) => {
        let fetchData = async () => {
            try{
                let response = await ContactService.deleteContact(contactId)
                if(response){
                    setState({...state, loading : true})
                    let response = await ContactService.getAllContacts();
                    console.log(response.data);
                    setState({
                        ...state,
                        loading : false,
                        contacts : response.data,
                        filteredContacts : response.data
                    })
                }
            }
            catch(error){
                setState({
                    ...state,
                    loading : false,
                    errorMessage : error.message
                })
            }
        }
        fetchData()
    }

    let [query, setQuery] = useState({
        text : ''
    })

    let searchContacts = (event) =>{
        setQuery({
            ...query,
            text: event.target.value
        })
        let items = state.contacts.filter(contact=>{
            return contact.name.toLowerCase().includes(event.target.value.toLowerCase())
        })
        setState({
            ...state,
            filteredContacts : items
        })
    }
    
    if(state.filteredContacts.length === 0){
        <h1>jdhjdhjhdjhdjjh</h1>
        console.log('gdjjdhjdhjdhjdhjhdjdjjd');
    }
    

    let {loading, contacts, filteredContacts} = state;

    return(
        <React.Fragment>
            <section className="serach-component">
                <div className="container mt-2">
                    <div className="row">
                        <div className="col">
                            <h1 className="fw-bold">Contact Manager 
                            <Link to={'/contacts/add'} className="btn btn-success">
                                new <i className="fa fa-plus-circle"></i>
                            </Link>
                            </h1>
                            <p className="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque molestiae quaerat cumque odio officia. Accusamus, ad enim vero, voluptatem optio culpa beatae tempore voluptates magni excepturi ab totam incidunt rem!</p>
                        </div>
                    </div>
                    <div className="row align-items-center">
                        <div className="col-md-4">
                            <form action="">
                                <div>
                                    <input 
                                    onChange={searchContacts}
                                    value={query.text} 
                                    type="text" className="form-control" placeholder="Search Here.. " />
                                </div>
                            </form>
                        </div>
                        <div className="col-md-3">
                            <button className="btn btn-outline-dark">Search</button>
                        </div>
                    </div>
                </div>
            </section>

            {
                loading ? <Spinner/> : <React.Fragment>
                    <section className="Contacts-list">
                <div className="container mt-5">
                    <div className="row">
                        {
                            filteredContacts.length>0 &&
                            filteredContacts.map(contact => {
                                return(
                                    <div className="col-md-6" key={contact.id}>
                            <div className="card shadow-lg my-2">
                                <div className="card-body">
                                    <div className="row align-items-center">
                                        <div className="col-md-4">
                                            <img className="img-fluid contact-img" src={contact.photo} alt="" />
                                        </div>
                                        <div className="col-md-7">
                                            <ul className="list-group">
                                                <li className="list-group-item list-group-item-action list-group-item-primary">
                                                    Name : <span>{contact.name}</span>
                                                </li>
                                                <li className="list-group-item list-group-item-action list-group-item-info">
                                                    Email : <span>{contact.email}</span>
                                                </li>
                                                <li className="list-group-item list-group-item-action list-group-item-warning">
                                                    Phone : <span>{contact.mobile}</span>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="col-md-1">
                                            <Link to={`/contacts/view/${contact.id}`} className="btn btn-warning btn-sm">
                                                <i className="fa fa-eye"></i>
                                            </Link>
                                            <Link to={`/contacts/update/${contact.id}`} className="btn btn-primary btn-sm">
                                                <i className="fa fa-edit"></i>
                                            </Link>
                                            <button onClick={()=>deleteContact(contact.id)} className="btn btn-danger btn-sm">
                                                <i className="fa fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                )
                            })
                        }
                    </div>
                </div>
            </section>
                </React.Fragment>
            }
            
            
        </React.Fragment>
    )
}

export default ContactList;