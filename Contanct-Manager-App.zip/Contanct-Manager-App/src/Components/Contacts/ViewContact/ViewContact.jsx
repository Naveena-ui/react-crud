import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import ContactService from "../../Services/ContactService";
import Spinner from "../../Spinner/Spinner";

let ViewContact = () => {

    let {contactId} = useParams();

    let [state, setState] = useState({
        loading : false,
        contact : {},
        group : {},
        errorMessage : ''
    })

    useEffect(()=>{
        let fecthData = async () => {
            try{
                setState({...state, loading : true})
                let response = await ContactService.getContact(contactId);
                let groupResponse = await ContactService.getGroup(response.data)
                // console.log(response.data)
                // console.log(groupResponse.data)
                setState({
                    ...state,
                    loading : false,
                    contact : response.data,
                    group : groupResponse.data
                })
            }
            catch(error){
                setState({
                    ...state,
                    loading : false,
                    errorMessage : error.message
                })
            }
        }
        fecthData()
    },[])

    let {loading, contact, group } = state;

    return(
        <React.Fragment>
            {
                loading ? <Spinner/> : <React.Fragment>
                    {
                        Object.keys(contact).length>0 && Object.keys(group).length>0 &&
                        <section className="view-contact">
                        <div className="container mt-5">
                        <div className="row d-flex align-items-center">
                        <div className="col-md-4">
                            <img src={contact.photo} className="img-fluid contact-img" alt="" />
                        </div>
                        <div className="col-md-8">
                            <ul className="list-group">
                                <li className="list-group-item list-group-item-action list-group-item-primary">
                                    Name : <span>{contact.name}</span>
                                </li>
                                <li className="list-group-item list-group-item-action list-group-item-info">
                                    Email : <span>{contact.email}</span>
                                </li>
                                <li className="list-group-item list-group-item-action list-group-item-warning">
                                    Phone : <span>{contact.mobile}</span>
                                </li>
                                <li className="list-group-item list-group-item-action list-group-item-warning">
                                    Company : <span>{contact.company}</span>
                                </li>
                                <li className="list-group-item list-group-item-action list-group-item-warning">
                                    Title : <span>{contact.title}</span>
                                </li>
                                <li className="list-group-item list-group-item-action list-group-item-warning">
                                    Group : <span>{group.name}</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <Link to={'/contacts/list'} className="btn btn-dark mx-5">Back</Link>
            </section>
                    }
                </React.Fragment>
            }
        </React.Fragment>
    )
}

export default ViewContact;