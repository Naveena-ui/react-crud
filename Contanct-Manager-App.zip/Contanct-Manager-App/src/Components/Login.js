
import React from "react";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import ContactService from "./Services/ContactService";

let Login = () => {

  let navigate = useNavigate()

  let [state, setState] = useState({
      loading : false,
      contact: {
         name:'',
          email: '',
          password: ''
      },
      errorMeassage: ''
  })

  useEffect(()=>{
      let fetchData = async () => {
          try{
              setState({...state, loading: true})
              let response = await ContactService.getAllGroups()
              // console.log(response.data);
              setState({
                  ...state,
                  loading: false,
                  groups: response.data
              })
          }
          catch(error){
              setState({
                  ...state,
                  loading: false,
                  errorMeassage: error.message
              })
          }
      }
      fetchData()
  },[])

  let updateInput = (event) => {
      setState({
          ...state,
          contact:{
              ...state.contact,
              [event.target.name]: event.target.value
          }
      })
  }

  let submitForm = (event) => {
      event.preventDefault();
      let fetchData = async () => {
          try{
              let response = await ContactService.createContact(contact)
              if(response){
                  navigate('/contacts/list',{replace: true})
              }
          }
          catch(error){
              setState({...state, errorMeassage: error.message})
              navigate('/contacts/add', {replace: false})
          }
      }
      fetchData()
  }

  let {contact, groups} = state;

  return(
      <React.Fragment>
          <section className="add-contact">
              <div className="container mt-2">
                  <div className="row d-flex justify-content-center">
                      <div className="col-md-4">
                          <h1 className="fw-bold">LogIn</h1>
                          <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Modi quibusdam at libero vel veniam necessitatibus delectus. Expedita numquam minus ipsum. Neque at vel recusandae eius magnam expedita enim laborum necessitatibus.</p>
                      </div>
                  </div>
              </div>
          </section>

          <section className="new-contact">
              <div className="container mt-5 ">
                  <div className="row d-flex justify-content-center">
                      <div className="col-md-4">
                          <form action="" onSubmit={submitForm}>
                          <div className="mb-2">
                                    <input 
                                    required={true}
                                    name="name"
                                    value={contact.name}
                                    onChange={updateInput}
                                    type="text" className="form-control" placeholder="Name" />
                                </div>
                              <div className="mb-2">
                                  <input 
                                  required={true}
                                  name="email"
                                  value={contact.email}
                                  onChange={updateInput}
                                  type="email" className="form-control" placeholder="Email" />
                              </div>
                              <div className="mb-2">
                                  <input 
                                  required={true}
                                  name="password"
                                  value={contact.password}
                                  onChange={updateInput}
                                  type="password" className="form-control" placeholder="password" />
                              </div>
                              <div className="row mt-2">
               <div className="col-md-3 mb-2">
               <Link to={'/signin'}
                    className="btn btn-warning me-2 px-3 can-btn"> Cancel</Link>
                </div>
                <div className="col-md-3 mb-2">
                  <button
                    type="submit"
                    className="btn btn-success me-2 px-3 sub-btn">Update</button>
                </div>
               </div>
                          </form>
                      </div>
                  </div>
              </div>
          </section>

         
      </React.Fragment>
  )
}

export default Login;
